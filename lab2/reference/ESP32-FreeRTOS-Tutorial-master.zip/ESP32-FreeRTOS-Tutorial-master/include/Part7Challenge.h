#include "config.h"

namespace Part7Challenge {
void producer(void *parameters);
void consumer(void *parameters);
void setup();
void loop();
}  // namespace Part7Challenge
