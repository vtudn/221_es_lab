#include "config.h"

namespace Part5 {
void printMessages(void* param);
void setup();
void loop();
}  // namespace Part5
