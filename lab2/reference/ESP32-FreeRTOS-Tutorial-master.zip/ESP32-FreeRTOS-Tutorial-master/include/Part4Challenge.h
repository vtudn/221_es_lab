#include "config.h"

namespace Part4Challenge {
void listenTask(void* param);
void echoTask(void* param);
void setup();
void loop();
}  // namespace Part4Challenge
