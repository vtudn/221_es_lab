#include "config.h"

namespace Part3Challenge {
void inputTask(void* param);
void blinkTask(void* param);
void setup();
void loop();
}  // namespace Part3Challenge
