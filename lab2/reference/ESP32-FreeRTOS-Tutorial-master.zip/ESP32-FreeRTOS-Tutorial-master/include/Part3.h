#include "config.h"
namespace Part3 {
void startTask1(void* param);
void startTask2(void* param);
void setup();
void loop();
}  // namespace Part3
