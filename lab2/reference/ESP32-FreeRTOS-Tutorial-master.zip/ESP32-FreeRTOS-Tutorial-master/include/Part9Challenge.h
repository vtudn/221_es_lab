#include "config.h"

namespace Part9Challenge {
void setup();
void loop();
}  // namespace Part9Challenge
