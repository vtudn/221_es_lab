#include "config.h"

namespace Part7 {
void blinkLED(void* param);
void myTask(void* param);
void setup();
void loop();
}
