#include "config.h"

namespace Part5Challenge {
void terminal(void* param);
void ledControl(void* param);
void setup();
void loop();
}  // namespace Part5Challenge
