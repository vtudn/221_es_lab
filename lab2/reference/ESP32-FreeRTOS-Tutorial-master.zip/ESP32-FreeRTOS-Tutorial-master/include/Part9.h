#include "config.h"

namespace Part9 {
void setup();
void loop();
}  // namespace Part9
