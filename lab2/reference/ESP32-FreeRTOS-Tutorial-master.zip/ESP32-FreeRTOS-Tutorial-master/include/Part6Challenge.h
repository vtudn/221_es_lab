#include "config.h"

namespace Part6Challenge {
void blinkLED(void* param);
void setup();
void loop();
}  // namespace Part6Challenge
