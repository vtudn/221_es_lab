#include "config.h"

namespace Part12 {
void setup();
void loop();
}  // namespace Part12
