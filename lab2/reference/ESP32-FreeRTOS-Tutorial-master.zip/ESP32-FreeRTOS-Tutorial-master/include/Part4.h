#include "config.h"

namespace Part4 {
void testTask(void* param);
void setup();
void loop();
}  // namespace Part4
