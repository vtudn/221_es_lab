#include "config.h"

namespace Part10 {
void setup();
void loop();
}  // namespace Part10
