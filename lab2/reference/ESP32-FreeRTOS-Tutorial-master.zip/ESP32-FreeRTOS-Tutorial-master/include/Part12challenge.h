#include "config.h"

namespace Part12Challenge {
void setup();
void loop();
}  // namespace Part12Challenge
