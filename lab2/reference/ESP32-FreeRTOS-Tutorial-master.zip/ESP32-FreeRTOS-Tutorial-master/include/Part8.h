#include "config.h"

namespace Part8 {
void timerCallback(TimerHandle_t xTimer);
void setup();
void loop();
}  // namespace Part8
