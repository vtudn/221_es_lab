#include "config.h"

namespace Part11Challenge {
void setup();
void loop();
}  // namespace Part11Challenge
