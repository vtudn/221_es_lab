#include "config.h"

namespace Part6 {
void incTask(void* param);
void setup();
void loop();
}  // namespace Part6
