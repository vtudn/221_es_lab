#include "config.h"

namespace Part11 {
void setup();
void loop();
}  // namespace Part11
