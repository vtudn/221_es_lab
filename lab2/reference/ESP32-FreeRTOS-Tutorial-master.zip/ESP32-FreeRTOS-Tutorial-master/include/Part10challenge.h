#include "config.h"

namespace Part10Challenge {
void setup();
void loop();
}  // namespace Part10Challenge
