#include "config.h"

namespace Part2 {
void toggleLED(void* param);
void toggleLED2(void* param);
void setup();
void loop();
}  // namespace Part2
