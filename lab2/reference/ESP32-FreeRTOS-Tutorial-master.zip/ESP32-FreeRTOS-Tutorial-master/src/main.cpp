// Choose which tutorial video will be built
#define PREFIX Part12Challenge

#include "Part10.h"
#include "Part10Challenge.h"
#include "Part11.h"
#include "Part11Challenge.h"
#include "Part12.h"
#include "Part12Challenge.h"
#include "Part2.h"
#include "Part3.h"
#include "Part3Challenge.h"
#include "Part4.h"
#include "Part4Challenge.h"
#include "Part5.h"
#include "Part5Challenge.h"
#include "Part6.h"
#include "Part6Challenge.h"
#include "Part7.h"
#include "Part7Challenge.h"
#include "Part8.h"
#include "Part8Challenge.h"
#include "Part9.h"
#include "Part9Challenge.h"

void setup() { PREFIX::setup(); }

void loop() { PREFIX::loop(); }
