#ifndef _CONNECT_H_
#define _CONNECT_H_

void wifiInit();


#endif