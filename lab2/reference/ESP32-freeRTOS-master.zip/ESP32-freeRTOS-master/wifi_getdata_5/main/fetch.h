#ifndef _FETCH_H_
#define _FETCH_H_

void fetch(char* url);

#endif