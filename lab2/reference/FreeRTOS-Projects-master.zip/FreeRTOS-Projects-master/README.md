# FreeRTOS-Projects
Projects built using FreeRTOS, a light-weight OS for embedded systems.
The projects are implemented using ESP32 dev-board.
Same code can be used for other microcontroller boards (which support freertos) by changing the header files.
